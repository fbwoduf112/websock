import React from 'react';
import StockPage from './StockPage';

function App() {
  return (
    <div className="App">
      <StockPage />
    </div>
  );
}

export default App;